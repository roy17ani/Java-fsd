import java.io.*;
import java.util.Scanner;
public class FileCRUDOperations {

	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Prompt user for file name
        System.out.print("Enter the file name: ");
        String fileName = scanner.nextLine();

        // Prompt user for file content
        System.out.print("Enter the file content: ");
        String content = scanner.nextLine();

        // File creation
        createFile(fileName);

        // File updating
        updateFile(fileName, content);

        // File reading after update
        readFile(fileName);

        // File deletion
        deleteFile(fileName);

        scanner.close();
    }

    // Method to create a file
    public static void createFile(String fileName) {
        try {
            File file = new File(fileName);
            if (file.createNewFile()) {
                System.out.println("File created: " + file.getName());
            } else {
                System.out.println("File already exists.");
            }
        } catch (IOException e) {
            System.out.println("An error occurred while creating the file.");
            e.printStackTrace();
        }
    }

    // Method to read content from a file
    public static void readFile(String fileName) {
        try {
            BufferedReader reader = new BufferedReader(new FileReader(fileName));
            String line;
            System.out.println("File content:");
            while ((line = reader.readLine()) != null) {
                System.out.println(line);
            }
            reader.close();
        } catch (IOException e) {
            System.out.println("An error occurred while reading the file.");
            e.printStackTrace();
        }
    }

    // Method to update content of a file
    public static void updateFile(String fileName, String content) {
        try {
            FileWriter writer = new FileWriter(fileName);
            writer.write(content);
            writer.close();
            System.out.println("File updated successfully.");
        } catch (IOException e) {
            System.out.println("An error occurred while updating the file.");
            e.printStackTrace();
        }
    }

    // Method to delete a file
    public static void deleteFile(String fileName) {
        File file = new File(fileName);
        if (file.delete()) {
            System.out.println("File deleted successfully: " + file.getName());
        } else {
            System.out.println("Failed to delete the file.");
        }
    }
}