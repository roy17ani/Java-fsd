import java.util.Scanner;
public class AccessModifier {

	private String privateData = "This is private data."; // Only accessible within this class

    public String publicData = "This is public data."; // Accessible anywhere

    protected void printProtectedMessage() { // Accessible within this class and subclasses (in different packages)
        System.out.println("This is a protected message.");
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        AccessModifier obj = new AccessModifier();

        // User Input Loop
        while (true) {
            System.out.println("\nAccess Modifier Menu:");
            System.out.println("1. Access Public Data");
            System.out.println("2. Call Protected Method (indirectly)");
            System.out.println("3. Exit");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline character after int input

            switch (choice) {
                case 1:
                    System.out.println("Public data: " + obj.publicData);
                    break;
                case 2:
                    System.out.println("Calling protected method indirectly...");
                    obj.callProtectedMethod(); // Call a public method that calls the protected method
                    break;
                case 3:
                    System.out.println("Exiting program.");
                    return;
                default:
                    System.out.println("Invalid Choice!");
            }
        }
    }

    // This public method calls the protected method, allowing access indirectly
    public void callProtectedMethod() {
        printProtectedMessage(); // Calls the protected method from within the class
    }
}