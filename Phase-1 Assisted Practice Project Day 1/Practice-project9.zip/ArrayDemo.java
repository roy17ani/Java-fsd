import java.util.Scanner;
public class ArrayDemo {

	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Input the size of the array from the user
        System.out.println("Enter the size of the array:");
        int size = scanner.nextInt();

        // Create an array of the specified size
        int[] array = new int[size];

        // Input array elements from the user
        System.out.println("Enter " + size + " integers to fill the array:");
        for (int i = 0; i < size; i++) {
            array[i] = scanner.nextInt();
        }

        // Display the array elements
        System.out.println("\nArray elements:");
        for (int i = 0; i < size; i++) {
            System.out.print(array[i] + " ");
        }

        scanner.close();
    }
}