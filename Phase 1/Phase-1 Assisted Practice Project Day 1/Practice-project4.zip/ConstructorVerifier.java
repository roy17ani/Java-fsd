import java.util.Scanner;
public class ConstructorVerifier {

	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // User Input Loop
        while (true) {
            System.out.println("\nConstructor Menu:");
            System.out.println("1. Create object with Default Constructor");
            System.out.println("2. Create object with Parameterized Constructor");
            System.out.println("3. Exit");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline character after int input

            switch (choice) {
                case 1:
                    createDefaultObject();
                    break;
                case 2:
                    createParameterizedObject(scanner);
                    break;
                case 3:
                    System.out.println("Exiting program.");
                    return;
                default:
                    System.out.println("Invalid Choice!");
            }
        }
    }

    public static void createDefaultObject() {
        System.out.println("Creating object with Default Constructor...");
        CustomClass obj = new CustomClass(); // Calls the default constructor (no arguments)
        System.out.println("Object created with default values!");
    }

    public static void createParameterizedObject(Scanner scanner) {
        System.out.print("Enter a value for the object: ");
        int value = scanner.nextInt();

        System.out.println("Creating object with Parameterized Constructor...");
        CustomClass obj = new CustomClass(value); // Calls the constructor with an argument
        System.out.println("Object created with value: " + obj.getData());
    }
}

class CustomClass {

    private int data;

    // Default constructor (no arguments)
    public CustomClass() {
        System.out.println("Default constructor called! Setting data to 0.");
        this.data = 0; // Set a default value
    }

    // Parameterized constructor with an int argument
    public CustomClass(int data) {
        System.out.println("Parameterized constructor called with value: " + data);
        this.data = data;
    }

    // Getter method for data
    public int getData() {
        return this.data;
    }

    // (Optional) Add methods to access or modify data if needed
}