import java.util.Scanner;
public class TypeCasting {

	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Implicit Type Casting (Widening)
        int intValue = 100;
        double doubleValue = intValue; // Implicit casting from int to double

        System.out.println("Implicit Type Casting (Widening):");
        System.out.println("int value: " + intValue);
        System.out.println("double value after implicit casting: " + doubleValue);

        // Explicit Type Casting (Narrowing)
        System.out.println("\nEnter a double value for explicit type casting (Narrowing):");
        double inputDouble = scanner.nextDouble();

        // Manually cast double to int
        int castedIntValue = (int) inputDouble; // Explicit casting from double to int

        System.out.println("Explicit Type Casting (Narrowing):");
        System.out.println("double value: " + inputDouble);
        System.out.println("int value after explicit casting: " + castedIntValue);

        scanner.close();
    }
}