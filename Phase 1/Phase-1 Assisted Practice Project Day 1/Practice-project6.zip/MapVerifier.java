import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
public class MapVerifier {

	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Create a HashMap
        Map<String, String> phonebook = new HashMap<>();

        // User Input Loop (add entries)
        while (true) {
            System.out.println("\nPhonebook Menu:");
            System.out.println("1. Add Entry (Name - Phone Number)");
            System.out.println("2. Find Phone Number by Name");
            System.out.println("3. Exit");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline character after int input

            switch (choice) {
                case 1:
                    addEntry(phonebook, scanner);
                    break;
                case 2:
                    findPhoneNumber(phonebook, scanner);
                    break;
                case 3:
                    System.out.println("Exiting program.");
                    return;
                default:
                    System.out.println("Invalid Choice!");
            }
        }
    }

    public static void addEntry(Map<String, String> phonebook, Scanner scanner) {
        System.out.print("Enter name: ");
        String name = scanner.nextLine();
        System.out.print("Enter phone number: ");
        String number = scanner.nextLine();

        phonebook.put(name, number); // Add entry to the Map (key-value pair)
        System.out.println("Entry added successfully!");
    }

    public static void findPhoneNumber(Map<String, String> phonebook, Scanner scanner) {
        System.out.print("Enter name to find phone number: ");
        String name = scanner.nextLine();

        if (phonebook.containsKey(name)) {
            String number = phonebook.get(name);
            System.out.println("Phone number for " + name + ": " + number);
        } else {
            System.out.println("Name not found in phonebook.");
        }
    }
}
