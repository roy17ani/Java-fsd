import java.util.Scanner;

class ListNode {
    int data;
    ListNode prev;
    ListNode next;

    public ListNode(int data) {
        this.data = data;
        this.prev = null;
        this.next = null;
    }
}
public class DoublyLinkedList {

	private ListNode head;
    private ListNode tail;

    public DoublyLinkedList() {
        this.head = null;
        this.tail = null;
    }

    public void insert(int data) {
        ListNode newNode = new ListNode(data);
        if (head == null) {
            head = newNode;
            tail = newNode;
        } else {
            tail.next = newNode;
            newNode.prev = tail;
            tail = newNode;
        }
    }

    public void forwardTraversal() {
        if (head == null) {
            System.out.println("List is empty");
            return;
        }
        ListNode current = head;
        System.out.println("Forward traversal:");
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }

    public void backwardTraversal() {
        if (tail == null) {
            System.out.println("List is empty");
            return;
        }
        ListNode current = tail;
        System.out.println("Backward traversal:");
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.prev;
        }
        System.out.println();
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        DoublyLinkedList list = new DoublyLinkedList();

        System.out.print("Enter the number of elements in the doubly linked list: ");
        int n = scanner.nextInt();
        System.out.println("Enter the elements of the doubly linked list:");
        for (int i = 0; i < n; i++) {
            int data = scanner.nextInt();
            list.insert(data);
        }

        list.forwardTraversal();
        list.backwardTraversal();

        scanner.close();
    }
}