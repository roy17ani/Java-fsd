import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class QueueExample {

	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Queue<Integer> queue = new LinkedList<>();

        // Input elements for the queue
        System.out.print("Enter the number of elements in the queue: ");
        int n = scanner.nextInt();
        System.out.println("Enter the elements of the queue:");
        for (int i = 0; i < n; i++) {
            int element = scanner.nextInt();
            queue.add(element);
        }

        // Display the initial queue
        System.out.println("Initial elements in the queue:");
        displayQueue(queue);

        // Perform insert or remove operations
        while (true) {
            System.out.println("\nQueue Operations:");
            System.out.println("1. Insert (Enqueue)");
            System.out.println("2. Remove (Dequeue)");
            System.out.println("3. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Enter the element to insert: ");
                    int insertElement = scanner.nextInt();
                    queue.add(insertElement);
                    System.out.println("Element " + insertElement + " inserted into the queue");
                    displayQueue(queue);
                    break;
                case 2:
                    if (queue.isEmpty()) {
                        System.out.println("Queue is empty. Cannot remove.");
                    } else {
                        System.out.print("Enter the element to remove: ");
                        int removeElement = scanner.nextInt();
                        if (queue.remove(removeElement)) {
                            System.out.println("Element " + removeElement + " removed from the queue");
                            displayQueue(queue);
                        } else {
                            System.out.println("Element not found in the queue.");
                        }
                    }
                    break;
                case 3:
                    System.out.println("Exiting...");
                    scanner.close();
                    System.exit(0);
                default:
                    System.out.println("Invalid choice. Please enter a valid option.");
            }
        }
    }

    // Method to display the elements of the queue
    public static void displayQueue(Queue<Integer> queue) {
        if (queue.isEmpty()) {
            System.out.println("Queue is empty");
        } else {
            System.out.println("Elements in the queue:");
            for (int num : queue) {
                System.out.print(num + " ");
            }
            System.out.println();
        }
    }
}