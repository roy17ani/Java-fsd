import java.util.Scanner;
public class SumInRange {

	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Taking input for the number of elements in the array
        System.out.print("Enter the number of elements in the array: ");
        int n = scanner.nextInt();
        int[] arr = new int[n];

        // Taking input for the elements of the array
        System.out.println("Enter the elements of the array:");
        for (int i = 0; i < n; i++) {
            arr[i] = scanner.nextInt();
        }

        // Taking input for the range [L, R]
        System.out.print("Enter the range [L, R] (0 <= L <= R <= n-1): ");
        int L = scanner.nextInt();
        int R = scanner.nextInt();

        // Validating the range
        if (L < 0 || R >= n || L > R) {
            System.out.println("Invalid range!");
        } else {
            // Calculating the sum of elements within the range [L, R]
            int sum = 0;
            for (int i = L; i <= R; i++) {
                sum += arr[i];
            }
            System.out.println("Sum of elements in the range [" + L + ", " + R + "]: " + sum);
        }

        scanner.close();
    }
}
