import java.util.Arrays;
import java.util.Scanner;
public class FourthSmallestElement {

	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Taking input for the list of integers
        System.out.print("Enter the number of elements in the list: ");
        int n = scanner.nextInt();
        int[] arr = new int[n];
        System.out.println("Enter the elements of the list:");
        for (int i = 0; i < n; i++) {
            arr[i] = scanner.nextInt();
        }

        // Finding the fourth smallest element
        int fourthSmallest = findFourthSmallest(arr);

        System.out.println("The fourth smallest element in the list is: " + fourthSmallest);

        scanner.close();
    }

    // Method to find the fourth smallest element in an array
    public static int findFourthSmallest(int[] arr) {
        Arrays.sort(arr); // Sorting the array in ascending order
        return arr[3]; // Fourth smallest element is at index 3 (0-based indexing)
    }
}