import java.util.Scanner;

class Item {
    int data;
    Item next;

    public Item(int data) {
        this.data = data;
        this.next = null;
    }
}

public class SortedCircularLinkedList {

	private Item head;

    public SortedCircularLinkedList() {
        this.head = null;
    }

    public void insert(int data) {
        Item newItem = new Item(data);

        // If list is empty
        if (head == null) {
            head = newItem;
            head.next = head; // Pointing back to itself to make it circular
        } else if (head.data >= newItem.data) { // Inserting before head
            Item last = getLastItem();
            newItem.next = head;
            head = newItem;
            last.next = head; // Updating the last node's next pointer
        } else {
            Item current = head;
            while (current.next != head && current.next.data < newItem.data) {
                current = current.next;
            }
            newItem.next = current.next;
            current.next = newItem;
        }
    }

    public Item getLastItem() {
        if (head == null) return null;

        Item current = head;
        while (current.next != head) {
            current = current.next;
        }
        return current;
    }

    public void display() {
        if (head == null) {
            System.out.println("List is empty");
            return;
        }
        Item current = head;
        do {
            System.out.print(current.data + " ");
            current = current.next;
        } while (current != head);
        System.out.println();
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        SortedCircularLinkedList list = new SortedCircularLinkedList();

        System.out.print("Enter the number of elements in the circular linked list: ");
        int n = scanner.nextInt();
        System.out.println("Enter the elements of the circular linked list (in ascending order):");
        for (int i = 0; i < n; i++) {
            int data = scanner.nextInt();
            list.insert(data);
        }

        System.out.print("Enter the element to insert: ");
        int newData = scanner.nextInt();
        list.insert(newData);

        System.out.println("Circular linked list after insertion:");
        list.display();

        scanner.close();
    }
}