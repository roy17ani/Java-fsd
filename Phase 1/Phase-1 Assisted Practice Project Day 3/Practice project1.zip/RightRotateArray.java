import java.util.Scanner;
public class RightRotateArray {

	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Taking input for array elements
        System.out.print("Enter the number of elements in the array: ");
        int n = scanner.nextInt();
        int[] arr = new int[n];
        System.out.println("Enter the elements of the array:");
        for (int i = 0; i < n; i++) {
            arr[i] = scanner.nextInt();
        }

        // Taking input for the number of steps to rotate
        System.out.print("Enter the number of steps to right rotate: ");
        int steps = scanner.nextInt();

        System.out.println("Original Array:");
        printArray(arr);

        // Right rotate the array by the given number of steps
        rightRotate(arr, steps);

        System.out.println("\nArray after right rotation by " + steps + " steps:");
        printArray(arr);

        scanner.close();
    }

    // Method to perform right rotation of array by 'steps' steps
    public static void rightRotate(int[] arr, int steps) {
        int n = arr.length;
        steps = steps % n; // Adjusting steps in case it's greater than array length

        reverse(arr, 0, n - 1); // Reverse the whole array
        reverse(arr, 0, steps - 1); // Reverse the first 'steps' elements
        reverse(arr, steps, n - 1); // Reverse the remaining elements
    }

    // Method to reverse an array or a portion of it
    public static void reverse(int[] arr, int start, int end) {
        while (start < end) {
            int temp = arr[start];
            arr[start] = arr[end];
            arr[end] = temp;
            start++;
            end--;
        }
    }

    // Method to print the array
    public static void printArray(int[] arr) {
        for (int num : arr) {
            System.out.print(num + " ");
        }
        System.out.println();
    }
}