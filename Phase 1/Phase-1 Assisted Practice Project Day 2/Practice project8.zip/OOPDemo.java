import java.util.Scanner;

// Parent class
class Shape {
    // Abstraction: Shape has an abstract method named calculateArea()
    public double calculateArea() {
        return 0.0;
    }
}

// Child class 1 - Rectangle (Inheritance)
class Rectangle extends Shape {
    private double length;
    private double width;

    public Rectangle(double length, double width) {
        this.length = length;
        this.width = width;
    }

    // Encapsulation: Private fields with public accessors
    public double getLength() {
        return length;
    }

    public double getWidth() {
        return width;
    }

    // Polymorphism: Override calculateArea() method
    @Override
    public double calculateArea() {
        return length * width;
    }
}

// Child class 2 - Circle (Inheritance)
class Circle extends Shape {
    private double radius;

    public Circle(double radius) {
        this.radius = radius;
    }

    // Encapsulation: Private field with a public accessor
    public double getRadius() {
        return radius;
    }

    // Polymorphism: Override calculateArea() method
    @Override
    public double calculateArea() {
        return Math.PI * radius * radius;
    }
}
public class OOPDemo {

	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Taking user input for rectangle dimensions
        System.out.print("Enter length of rectangle: ");
        double length = scanner.nextDouble();
        System.out.print("Enter width of rectangle: ");
        double width = scanner.nextDouble();
        Rectangle rectangle = new Rectangle(length, width);

        // Taking user input for circle radius
        System.out.print("Enter radius of circle: ");
        double radius = scanner.nextDouble();
        Circle circle = new Circle(radius);

        scanner.close();

        // Displaying calculated areas
        System.out.println("\nRectangle Area:");
        System.out.println("Length: " + rectangle.getLength() + ", Width: " + rectangle.getWidth());
        System.out.println("Area: " + rectangle.calculateArea());

        System.out.println("\nCircle Area:");
        System.out.println("Radius: " + circle.getRadius());
        System.out.println("Area: " + circle.calculateArea());
    }
}