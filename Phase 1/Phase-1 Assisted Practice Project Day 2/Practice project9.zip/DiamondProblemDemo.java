interface A {
    default void display() {
        System.out.println("Inside interface A");
    }
}

// Interface B extending A
interface B extends A {
    // no methods
}

// Interface C extending A
interface C extends A {
    // no methods
}

// Interface D extending both B and C
interface D extends B, C {
    // no methods
}

// Class implementing D
class MyClass implements D {
    // Overrides display() method to resolve ambiguity
    public void display() {
        System.out.println("Inside MyClass");
    }
}

public class DiamondProblemDemo {

	public static void main(String[] args) {
        MyClass obj = new MyClass();
        obj.display();
    }
}