import java.util.Scanner;
public class SynchronizationDemo {

	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Enter the number of threads: ");
        int numThreads = scanner.nextInt();
        
        System.out.print("Enter the number of increments per thread: ");
        int numIncrements = scanner.nextInt();
        
        Counter counter = new Counter();

        Thread[] threads = new Thread[numThreads];
        
        for (int i = 0; i < numThreads; i++) {
            threads[i] = new Thread(new IncrementTask(counter, numIncrements));
            threads[i].start();
        }
        
        // Wait for all threads to finish
        for (Thread thread : threads) {
            try {
                thread.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        
        System.out.println("Final counter value: " + counter.getCount());
        
        scanner.close();
    }
}

class Counter {
    private int count = 0;

    public synchronized void increment() {
        // Synchronized method ensures only one thread can execute this method at a time
        count++;
    }
    
    public int getCount() {
        return count;
    }
}

class IncrementTask implements Runnable {
    private Counter counter;
    private int numIncrements;

    public IncrementTask(Counter counter, int numIncrements) {
        this.counter = counter;
        this.numIncrements = numIncrements;
    }

    @Override
    public void run() {
        // Each thread will call the increment method of the Counter object
        for (int i = 0; i < numIncrements; i++) {
            counter.increment();
            try {
                Thread.sleep(100); // Just to simulate some processing time
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}