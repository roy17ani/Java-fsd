import java.util.Scanner;
public class StringConversion {

	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Get user input for the string
        System.out.print("Enter a string: ");
        String userInput = scanner.nextLine();

        // Create a StringBuffer from the string
        StringBuffer stringBuffer = new StringBuffer(userInput);

        // Create a StringBuilder from the string
        StringBuilder stringBuilder = new StringBuilder(userInput);

        // Display the original string
        System.out.println("\nOriginal String: " + userInput);

        // Display the converted StringBuffer (unchanged)
        System.out.println("Converted to StringBuffer: " + stringBuffer);

        // Modify the StringBuilder (demonstrates mutability)
        stringBuilder.append(" (appended text)");

        // Display the modified StringBuilder
        System.out.println("Modified StringBuilder: " + stringBuilder);
    }
}
