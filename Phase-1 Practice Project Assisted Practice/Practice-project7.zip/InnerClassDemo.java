import java.util.Scanner;
public class InnerClassDemo {

	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Get user input for outer class name
        System.out.print("Enter the name of the outer class: ");
        String outerClassName = scanner.nextLine();

        // Get user input for inner class name
        System.out.print("Enter the name of the inner class: ");
        String innerClassName = scanner.nextLine();

        // Create and display an instance of the outer class
        Outer obj = new Outer();
        System.out.println("\nOuter Class Object Created!");

        // Access inner class method using outer class object (assuming a public method)
        if (obj.hasInnerClass(innerClassName)) {
            System.out.println("Inner class method call (assuming a public method): " + obj.getInnerMessage());
        } else {
            System.out.println("Inner class '" + innerClassName + "' not found in outer class.");
        }
    }

    // Outer class with a public method to access the inner class (assuming a public method)
    public static class Outer {

        public String getInnerMessage() {
            Inner inner = new Inner(); // Create an inner class instance
            return inner.getInnerText();
        }

        public boolean hasInnerClass(String name) {
            // Simulate checking for inner class existence (replace with actual logic if possible)
            return name.equals("Inner"); // Replace with your logic to check for inner class by name
        }

        // Inner class with a method to return a message
        private class Inner {
            public String getInnerText() {
                return "This message is from the inner class!";
            }
        }
    }
}
