import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class RegexVerifier {

	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Prompt user to enter regular expression
        System.out.print("Enter a regular expression: ");
        String regex = scanner.nextLine();

        // Prompt user to enter input string
        System.out.print("Enter the input string to verify: ");
        String input = scanner.nextLine();

        // Compile the regular expression
        Pattern pattern = Pattern.compile(regex);

        // Create a matcher with the input string
        Matcher matcher = pattern.matcher(input);

        // Verify if input matches the regular expression
        if (matcher.matches()) {
            System.out.println("Input matches the regular expression.");
        } else {
            System.out.println("Input does not match the regular expression.");
        }

        scanner.close();
    }
}