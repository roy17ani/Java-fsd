import java.util.Scanner;
import java.util.Stack;
public class StackExample {

	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Stack<Integer> stack = new Stack<>();

        // Input elements for the stack
        System.out.print("Enter the number of elements in the stack: ");
        int n = scanner.nextInt();
        System.out.println("Enter the elements of the stack:");
        for (int i = 0; i < n; i++) {
            int element = scanner.nextInt();
            stack.push(element);
        }

        // Display the initial stack
        System.out.println("Initial elements in the stack:");
        displayStack(stack);

        // Perform insert or remove operations
        while (true) {
            System.out.println("\nStack Operations:");
            System.out.println("1. Insert (Push)");
            System.out.println("2. Remove (Pop)");
            System.out.println("3. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Enter the element to insert: ");
                    int insertElement = scanner.nextInt();
                    stack.push(insertElement);
                    System.out.println("Element " + insertElement + " pushed into the stack");
                    displayStack(stack);
                    break;
                case 2:
                    if (stack.isEmpty()) {
                        System.out.println("Stack is empty. Cannot pop.");
                    } else {
                        System.out.print("Enter the element to remove: ");
                        int removeElement = scanner.nextInt();
                        if (stack.remove((Integer) removeElement)) {
                            System.out.println("Element " + removeElement + " removed from the stack");
                            displayStack(stack);
                        } else {
                            System.out.println("Element not found in the stack.");
                        }
                    }
                    break;
                case 3:
                    System.out.println("Exiting...");
                    scanner.close();
                    System.exit(0);
                default:
                    System.out.println("Invalid choice. Please enter a valid option.");
            }
        }
    }

    // Method to display the elements of the stack
    public static void displayStack(Stack<Integer> stack) {
        if (stack.isEmpty()) {
            System.out.println("Stack is empty");
        } else {
            System.out.println("Elements in the stack:");
            for (int i = stack.size() - 1; i >= 0; i--) {
                System.out.println(stack.get(i));
            }
        }
    }
}
