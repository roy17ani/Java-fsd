import java.util.Scanner;
public class LinearSearch {

	public static int search(int arr[], int n, int x) {
	    // Traverse through the array
	    for (int i = 0; i < n; i++) {
	      // If the element is found return its index
	      if (arr[i] == x) {
	        return i;
	      }
	    }
	    // If element is not found return -1
	    return -1;
	  }

	  public static void main(String args[]) {
	    Scanner scanner = new Scanner(System.in);

	    System.out.print("Enter the size of the array: ");
	    int n = scanner.nextInt();

	    int arr[] = new int[n];

	    System.out.println("Enter the elements of the array:");
	    for (int i = 0; i < n; i++) {
	      arr[i] = scanner.nextInt();
	    }

	    System.out.print("Enter the element to search: ");
	    int x = scanner.nextInt();

	    // Function call to search x in arr
	    int result = search(arr, n, x);

	    if (result == -1) {
	      System.out.println("Element is not present in array");
	    } else {
	      System.out.println("Element is present at index " + result);
	    }

	    scanner.close();
	  }
	}