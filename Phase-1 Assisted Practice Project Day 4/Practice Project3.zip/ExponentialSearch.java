
public class ExponentialSearch {

	public static int exponentialSearch(int arr[], int n, int x) {
	    // If first element is the target element, return its index
	    if (arr[0] == x) {
	      return 0;
	    }

	    // Find the range for binary search by repeated doubling
	    int i = 1;
	    while (i < n && arr[i] <= x) {
	      i = i * 2;
	    }

	    // Narrow down the search range using binary search on a subarray
	    return binarySearch(arr, i / 2, Math.min(i, n - 1), x);
	  }

	  // Utility function for binary search
	  public static int binarySearch(int arr[], int low, int high, int x) {
	    if (low <= high) {
	      int mid = low + (high - low) / 2;

	      if (arr[mid] == x) {
	        return mid;
	      } else if (arr[mid] < x) {
	        return binarySearch(arr, mid + 1, high, x);
	      } else {
	        return binarySearch(arr, low, mid - 1, x);
	      }
	    }
	    return -1;
	  }

	  public static void main(String args[]) {
	    int arr[] = {2, 3, 4, 10, 40};
	    int n = arr.length;
	    int x = 10;

	    // Function call to search x in arr
	    int result = exponentialSearch(arr, n, x);

	    if (result == -1) {
	      System.out.println("Element is not present in array");
	    } else {
	      System.out.println("Element is present at index " + result);
	    }
	  }
	}
